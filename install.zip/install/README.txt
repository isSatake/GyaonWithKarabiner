-- KarabinerでGyaonを実行する --

設定方法
1. Karabiner.appをインストールする
2. install/private.xmlをKarabinerにロードする
   ~/Library/Application Support/Karabiner/ にコピーするか、
   内容をコピーして貼り付てください
3. install/install.shを実行する

使用方法
右⌘ + FN を同時に長押しで録音開始
離すと録音停止 -> アップロード

サーバーやユーザIDの変更
~/.gyaon/gyaonid.txt,
~/.gyaon/server.txt を変更してください
